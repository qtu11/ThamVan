#requires -Version 5.1
[CmdletBinding()]
param(
  [string]$OutputDir='D:\thamvan\public\images',
  [int]$MaxPlaces=0,
  [int]$Offset=0,
  [switch]$NoOSM,
  [switch]$NoOpenverse,
  [switch]$DryRun
)
$ErrorActionPreference='Stop'
& (Join-Path $PSScriptRoot 'Download-ThamVanImages-V3.ps1') -OutputDir $OutputDir -Offset $Offset -MaxPlaces $MaxPlaces -NoOSM:$NoOSM -NoOpenverse:$NoOpenverse -DryRun:$DryRun
& (Join-Path $PSScriptRoot 'Audit-ThamVanImages.ps1') -OutputDir $OutputDir
